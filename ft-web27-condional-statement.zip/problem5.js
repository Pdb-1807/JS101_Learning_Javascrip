let super_market="closeup";


if(super_market=="closeup")
  console.log("please")