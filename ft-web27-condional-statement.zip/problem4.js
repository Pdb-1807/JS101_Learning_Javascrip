let name1="masai";
let name2="goku";
console.log("enter condition");

if(name1===name2)
{
  console.log("the both are same");
}
else
{
  console.log("the both are not same");
}