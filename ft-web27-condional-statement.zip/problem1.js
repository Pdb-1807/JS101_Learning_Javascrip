console.log("Enter code");
let home_work="false";
if(home_work){
  console.log("my code is true");
            
}