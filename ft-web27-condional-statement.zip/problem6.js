let a,b,c;
a=3,b=4,c=5;
if(a==b){
  console.log("a&b are same");
}
 else if(b==c)
  
{
  console.log("b&c are same");
}
else if(c==a);
{
  console.log("c&a are same")
}
