console.log("write you want");
let name1="masai";
let name2="goku";
let a;
a=name1==name2;
if(a){
  console.log("the both name are same");
}
else{
console.log("the name are not same");
}