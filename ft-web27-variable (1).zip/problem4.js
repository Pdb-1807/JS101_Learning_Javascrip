let name,school,grade,section,rollno,mark;
name="purushottam bhade";
school="ssvm pandhurna";
grade=12;
section="A";
rollno=297;
let physics=80,chemistry=89,maths=99;
console.log("**","***********************************","**");
console.log("**","************REPORT CARD************","**");
console.log("**","# name:",name ,"                   ");
console.log("**","# school:",school,                   );
console.log("**","# section:",section,                 );
console.log("**","# rollno:",rollno,                   );
console.log("**","# subject:-"                        );
console.log("**","         * physics=",physics)
console.log("**","         * chemistry=",chemistry    );
console.log("**","         * maths=",maths            );
console.log("**","***********************************","**");
console.log("**","***********************************","**");
