let name,age;
name="purushottam bhade";
age=23;
console.log(name);
console.log(age);