let name="purushottam bhade";
console.log(name);
name="devidas bhade";
console.log(name);
name="imal bhade";
console.log(name);