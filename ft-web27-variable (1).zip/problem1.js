console.log("Masai school");
console.log("A Transformation in Education");